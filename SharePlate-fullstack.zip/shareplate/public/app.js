'use strict';
const $ = s => document.querySelector(s), esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const S = { me: null, view: 'home', lang: localStorage.getItem('lang') || 'en', stats: null, partners: [], listings: [], notes: [], auto: true, geo: null, mode: 'login' };
const T = {
  en: { tag: 'Good food. Shared with care.', home: 'Home', dash: 'Dashboard', partners: 'Partners', alerts: 'Alerts', login: 'Log in', signup: 'Sign up', logout: 'Log out',
    h1: 'Good food should feed people, not bins.', p: 'SharePlate helps hostels safely send surplus cooked food to nearby orphanages, old-age homes and trusts — with food-safety timers, smart matching and instant alerts.', start: 'Start donating', join: 'Register your organization',
    meals: 'Meals rescued', kg: 'Food saved (kg, est.)', co2: 'CO₂ avoided (kg, est.)', pcount: 'Partner organizations', top: 'Top donors', topEmpty: 'The first delivered donation will appear here.',
    how: 'How it works', how1: 'List leftover food with the time it was made and how it was kept.', how2: 'We rank nearby partners by distance, capacity and diet, and alert them.', how3: 'A partner claims it, collects it, and you both get live updates.',
    food: 'Food type', fmeals: 'Approx. meals', veg: 'Vegetarian only', area: 'Area / locality', prep: 'Food prepared at', store: 'How has it been kept?', notes: 'Extra details (optional)', phone: 'Contact number', loc: 'Use my location', locOk: 'Location added ✓',
    autoOn: 'Automatic alerts ON — top 3 partners are alerted immediately.', autoOff: 'Automatic alerts OFF — choose partners yourself.', safety: '⚠ Food safety first. Only donate food that was handled safely. The app blocks unknown storage and food past its safe-time window, but a responsible person must always check the food.', submit: 'Find a nearby partner',
    mine: 'My listings', none: 'Nothing here yet.', left: 'left', alertBtn: 'Alert', alerted: 'Alerted', cancel: 'Cancel listing', report: 'Download report (CSV)', best: 'Best fit',
    incoming: 'Food available near you', claims: 'My pickups', claim: 'Claim this food', picked: 'Mark picked up', delivered: 'Mark delivered', away: 'km away', contact: 'Contact',
    st_open: 'Open', st_claimed: 'Claimed', st_picked_up: 'Picked up', st_delivered: 'Delivered', st_expired: 'Expired', st_cancelled: 'Cancelled',
    email: 'Email', pw: 'Password (8+ characters)', name: 'Your name', org: 'Organization name', otype: 'Organization type', cap: 'Meals you can take', vonly: 'We accept vegetarian food only', iam: 'I am a', donor: 'Hostel / school / college', partner: 'Orphanage / old-age home / trust',
    verified: 'Verified', unverified: 'Not verified yet', demo: 'Demo', noAlerts: 'No alerts yet.', markRead: 'Mark all read', needLogin: 'Please log in first.', saved: 'Listing created.', foot: 'SharePlate does not certify food safety. Always verify partners and follow local food-safety rules. Impact numbers are estimates (0.4 kg and 1 kg food ≈ 2.5 kg CO₂ per meal assumption).',
    f_Hot: 'Kept hot safely (4 h limit)', f_Ref: 'Refrigerated promptly (12 h limit)', f_Room: 'Room temperature (2 h limit)', f_Unk: 'Not sure', Orphanage: 'Orphanage', 'Old-age home': 'Old-age home', 'Community trust': 'Community trust', 'Community kitchen': 'Community kitchen' },
  te: { tag: 'మంచి ఆహారం. శ్రద్ధతో పంచుకుందాం.', home: 'హోమ్', dash: 'డాష్‌బోర్డ్', partners: 'భాగస్వాములు', alerts: 'అలర్ట్‌లు', login: 'లాగిన్', signup: 'సైన్ అప్', logout: 'లాగౌట్',
    h1: 'మంచి ఆహారం చెత్తలో కాదు, ఆకలితో ఉన్నవారికి చేరాలి.', p: 'SharePlate హాస్టళ్లలో మిగిలిన వండిన ఆహారాన్ని సమీప అనాథాశ్రమాలు, వృద్ధాశ్రమాలు, ట్రస్టులకు సురక్షితంగా చేరుస్తుంది — ఆహార భద్రత టైమర్లు, స్మార్ట్ మ్యాచింగ్, తక్షణ అలర్ట్‌లతో.', start: 'దానం ప్రారంభించండి', join: 'మీ సంస్థను నమోదు చేయండి',
    meals: 'రక్షించిన భోజనాలు', kg: 'ఆదా చేసిన ఆహారం (కిలోలు, అంచనా)', co2: 'తగ్గిన CO₂ (కిలోలు, అంచనా)', pcount: 'భాగస్వామ్య సంస్థలు', top: 'అగ్ర దాతలు', topEmpty: 'మొదటి డెలివరీ ఇక్కడ కనిపిస్తుంది.',
    how: 'ఎలా పనిచేస్తుంది', how1: 'మిగిలిన ఆహారం, వండిన సమయం, ఎలా ఉంచారో నమోదు చేయండి.', how2: 'దూరం, సామర్థ్యం, ఆహార రకం ఆధారంగా సమీప భాగస్వాములకు అలర్ట్ వెళ్తుంది.', how3: 'భాగస్వామి క్లెయిమ్ చేసి తీసుకెళ్తారు; ఇద్దరికీ లైవ్ అప్‌డేట్లు వస్తాయి.',
    food: 'ఆహార రకం', fmeals: 'సుమారు భోజనాలు', veg: 'శాకాహారం మాత్రమే', area: 'ప్రాంతం', prep: 'ఆహారం తయారైన సమయం', store: 'ఎలా నిల్వ చేశారు?', notes: 'ఇతర వివరాలు (ఐచ్ఛికం)', phone: 'ఫోన్ నంబర్', loc: 'నా లొకేషన్ వాడండి', locOk: 'లొకేషన్ చేర్చబడింది ✓',
    autoOn: 'ఆటోమేటిక్ అలర్ట్‌లు ఆన్ — టాప్ 3 భాగస్వాములకు వెంటనే అలర్ట్.', autoOff: 'ఆటోమేటిక్ అలర్ట్‌లు ఆఫ్ — భాగస్వాములను మీరే ఎంచుకోండి.', safety: '⚠ ఆహార భద్రత ముఖ్యం. సురక్షితంగా నిర్వహించిన ఆహారాన్నే ఇవ్వండి. తెలియని నిల్వ లేదా సమయం మించిన ఆహారాన్ని యాప్ అడ్డుకుంటుంది, అయినా బాధ్యతగల వ్యక్తి ఆహారాన్ని తప్పక పరిశీలించాలి.', submit: 'సమీప భాగస్వామిని కనుగొనండి',
    mine: 'నా లిస్టింగ్‌లు', none: 'ఇంకా ఏమీ లేదు.', left: 'మిగిలింది', alertBtn: 'అలర్ట్', alerted: 'అలర్ట్ పంపబడింది', cancel: 'లిస్టింగ్ రద్దు', report: 'రిపోర్ట్ డౌన్‌లోడ్ (CSV)', best: 'ఉత్తమ ఎంపిక',
    incoming: 'మీ సమీపంలో ఆహారం', claims: 'నా పికప్‌లు', claim: 'ఈ ఆహారం క్లెయిమ్ చేయండి', picked: 'తీసుకున్నాం', delivered: 'అందజేశాం', away: 'కి.మీ దూరం', contact: 'సంప్రదించండి',
    st_open: 'తెరిచి ఉంది', st_claimed: 'క్లెయిమ్ అయ్యింది', st_picked_up: 'తీసుకున్నారు', st_delivered: 'అందజేశారు', st_expired: 'గడువు ముగిసింది', st_cancelled: 'రద్దయింది',
    email: 'ఇమెయిల్', pw: 'పాస్‌వర్డ్ (8+ అక్షరాలు)', name: 'మీ పేరు', org: 'సంస్థ పేరు', otype: 'సంస్థ రకం', cap: 'మీరు తీసుకోగల భోజనాలు', vonly: 'మేము శాకాహారం మాత్రమే తీసుకుంటాము', iam: 'నేను', donor: 'హాస్టల్ / పాఠశాల / కళాశాల', partner: 'అనాథాశ్రమం / వృద్ధాశ్రమం / ట్రస్ట్',
    verified: 'ధృవీకరించబడింది', unverified: 'ఇంకా ధృవీకరించలేదు', demo: 'డెమో', noAlerts: 'అలర్ట్‌లు లేవు.', markRead: 'అన్నీ చదివినట్లు గుర్తించు', needLogin: 'ముందుగా లాగిన్ అవ్వండి.', saved: 'లిస్టింగ్ సృష్టించబడింది.', foot: 'SharePlate ఆహార భద్రతను ధృవీకరించదు. భాగస్వాములను తప్పక ధృవీకరించండి. ప్రభావ సంఖ్యలు అంచనాలు మాత్రమే.',
    f_Hot: 'వేడిగా సురక్షితంగా (4 గం. పరిమితి)', f_Ref: 'వెంటనే ఫ్రిజ్‌లో (12 గం. పరిమితి)', f_Room: 'గది ఉష్ణోగ్రత (2 గం. పరిమితి)', f_Unk: 'తెలియదు', Orphanage: 'అనాథాశ్రమం', 'Old-age home': 'వృద్ధాశ్రమం', 'Community trust': 'కమ్యూనిటీ ట్రస్ట్', 'Community kitchen': 'కమ్యూనిటీ కిచెన్' }
};
const t = k => T[S.lang][k] ?? T.en[k] ?? k;
const FOODS = ['Cooked rice & curry', 'Chapati / roti', 'Vegetables', 'Fruit', 'Packaged food', 'Other prepared food'], TYPES = ['Orphanage', 'Old-age home', 'Community trust', 'Community kitchen'];
async function api(p, m = 'GET', b) { const r = await fetch('/api/' + p, { method: m, headers: { 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined }); const j = await r.json().catch(() => ({})); if (!r.ok) throw new Error(j.error || 'Something went wrong'); return j; }
function toast(m) { const e = $('#toast'); e.textContent = m; e.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => e.classList.remove('show'), 3500); }
const left = ms => { if (ms <= 0) return '0m'; const m = Math.floor(ms / 6e4); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };
const pill = s => `<span class="pill ${s === 'open' ? 'a' : ['expired', 'cancelled'].includes(s) ? 'x' : ''}">${esc(t('st_' + s))}</span>`;
const nowTime = () => { const d = new Date(Date.now() - 36e5); return d.toTimeString().slice(0, 5); };

async function load(poll) {
  try { S.me = (await api('me')).user; } catch {}
  S.stats = await api('stats').catch(() => null); S.partners = (await api('partners').catch(() => ({ partners: [] }))).partners;
  if (S.me) { S.listings = (await api('listings').catch(() => ({ listings: [] }))).listings; S.notes = (await api('notifications').catch(() => ({ notes: [] }))).notes; }
  render(poll);
}
function nav() {
  const b = (v, l) => `<button data-a="go" data-v="${v}" class="${S.view === v ? 'active' : ''}">${l}</button>`, unread = S.notes.filter(n => !n.read).length;
  $('#nav').innerHTML = b('home', t('home')) + (S.me ? b('dash', t('dash')) : '') + b('partners', t('partners')) + (S.me ? `<button data-a="go" data-v="alerts" class="${S.view === 'alerts' ? 'active' : ''}">${t('alerts')}${unread ? `<span class="dot">${unread}</span>` : ''}</button><button class="ghost" data-a="logout">${t('logout')}</button>` : `<button class="ghost" data-a="auth" data-m="login">${t('login')}</button><button class="primary" data-a="auth" data-m="signup">${t('signup')}</button>`) + `<button class="ghost" data-a="lang" aria-label="Language">${S.lang === 'en' ? 'తెలుగు' : 'English'}</button>`;
  $('#tag').textContent = t('tag'); $('#foot').textContent = t('foot'); document.documentElement.lang = S.lang;
}
function home() {
  const s = S.stats || { meals: 0, kg: 0, co2: 0, partners: 0, top: [] };
  return `<section class="hero"><div><h1>${t('h1')}</h1><p>${t('p')}</p><div class="cta"><button class="primary" data-a="${S.me ? 'go' : 'auth'}" data-v="dash" data-m="signup">${t('start')}</button><button class="ghost" data-a="auth" data-m="signup">${t('join')}</button></div></div>
  <div class="impact"><b>${s.meals.toLocaleString()}</b><span>${t('meals')}</span><hr><span>${s.kg.toLocaleString()} ${t('kg')}</span><span>${s.co2.toLocaleString()} ${t('co2')}</span><span>${s.partners} ${t('pcount')}</span></div></section>
  <div class="grid"><section class="panel"><h3>${t('how')}</h3><div class="list"><p class="sub">1. ${t('how1')}</p><p class="sub">2. ${t('how2')}</p><p class="sub">3. ${t('how3')}</p></div></section>
  <section class="panel"><h3>${t('top')}</h3>${s.top.length ? `<div class="list">${s.top.map((x, i) => `<div class="row card"><b>${i + 1}. ${esc(x.name)}</b><span class="pill">${x.meals} ${t('meals').toLowerCase()}</span></div>`).join('')}</div>` : `<div class="empty">${t('topEmpty')}</div>`}</section></div>`;
}
function donorDash() {
  const m = S.me, opts = (a, f) => a.map(v => `<option value="${esc(v)}">${esc(f ? f(v) : v)}</option>`).join('');
  return `<div class="grid"><section class="panel"><h3>${t('dash')}</h3><form id="listForm"><div class="formgrid">
  <div class="field"><label>${t('food')}</label><select name="food">${opts(FOODS)}</select></div>
  <div class="field"><label>${t('fmeals')}</label><input name="meals" type="number" min="1" max="5000" value="40" required></div>
  <div class="field"><label>${t('area')}</label><input name="area" value="${esc(m.area)}" required></div>
  <div class="field"><label>${t('prep')}</label><input name="time" type="time" value="${nowTime()}" required></div>
  <div class="field"><label>${t('store')}</label><select name="storage"><option value="Hot-held">${t('f_Hot')}</option><option value="Refrigerated">${t('f_Ref')}</option><option value="Room temperature">${t('f_Room')}</option><option value="Unknown">${t('f_Unk')}</option></select></div>
  <div class="field"><label>${t('phone')}</label><input name="contact" type="tel" value="${esc(m.phone)}"></div>
  <label class="field check full"><input name="veg" type="checkbox"> ${t('veg')}</label>
  <div class="field full"><label>${t('notes')}</label><textarea name="notes" rows="2"></textarea></div></div>
  <button type="button" class="small" data-a="geo">${S.geo ? t('locOk') : '📍 ' + t('loc')}</button>
  <div class="mode"><span>${S.auto ? t('autoOn') : t('autoOff')}</span><input type="checkbox" data-a="auto" ${S.auto ? 'checked' : ''} aria-label="Automatic alerts"></div>
  <div class="safety">${t('safety')}</div><div class="err" id="formErr" role="alert"></div><button class="primary full-btn" type="submit">✦ ${t('submit')}</button></form></section>
  <section class="panel"><h3>${t('mine')}</h3><div class="acts" style="margin:0 0 12px"><a class="small" href="/api/report.csv">⬇ ${t('report')}</a></div><div class="list">${S.listings.length ? S.listings.map(donorCard).join('') : `<div class="empty">${t('none')}</div>`}</div></section></div>`;
}
function donorCard(l) {
  const live = ['open', 'claimed'].includes(l.status), ms = l.expiresAt - Date.now();
  return `<article class="card"><div class="row"><div><h4>${esc(l.food)} · ${l.meals}</h4><p>${esc(l.area)}${l.veg ? ' · 🌱' : ''}${live ? ` · ⏱ ${left(ms)} ${t('left')}` : ''}${l.claimedName ? `<br>→ ${esc(l.claimedName)}` : ''}</p></div>${pill(l.status)}</div>
  ${l.status === 'open' ? `<div class="list" style="margin-top:10px">${(l.matches || []).slice(0, 3).map((x, i) => `<div class="row"><p>${i === 0 ? '⭐ ' : ''}${esc(x.name)}${x.km != null ? ` · ${x.km} ${t('away')}` : ''}</p>${(l.alerted || []).includes(x.partnerId) ? `<span class="pill">${t('alerted')}</span>` : `<button class="small g" data-a="alert" data-id="${l.id}" data-p="${x.partnerId}">${t('alertBtn')}</button>`}</div>`).join('')}</div>` : ''}
  ${live ? `<div class="acts"><button class="small r" data-a="cancel" data-id="${l.id}">${t('cancel')}</button></div>` : ''}</article>`;
}
function partnerDash() {
  const open = S.listings.filter(l => l.status === 'open'), mine = S.listings.filter(l => l.claimedBy === S.me.partnerId && l.status !== 'open');
  const card = l => { const ms = l.expiresAt - Date.now(), nx = { claimed: ['picked_up', 'picked'], picked_up: ['delivered', 'delivered'] }[l.status];
    return `<article class="card"><div class="row"><div><h4>${esc(l.donorName)} · ${l.meals} ${t('meals').toLowerCase()}</h4><p>${esc(l.food)}${l.veg ? ' · 🌱' : ''} · ${esc(l.area)}${l.km != null ? ` · ${l.km} ${t('away')}` : ''}<br>⏱ ${left(ms)} ${t('left')}${l.notes ? `<br>${esc(l.notes)}` : ''}${l.contact ? `<br>☎ ${t('contact')}: ${esc(l.contact)}` : ''}</p></div>${l.status === 'open' ? (l.alerted ? `<span class="pill a">${t('alerted')}</span>` : '') : pill(l.status)}</div>
    <div class="acts">${l.status === 'open' ? `<button class="small g" data-a="claim" data-id="${l.id}">${t('claim')}</button>` : nx ? `<button class="small g" data-a="status" data-id="${l.id}" data-s="${nx[0]}">${t(nx[1])}</button>` : ''}</div></article>`; };
  return `<div class="grid"><section class="panel"><h3>${t('incoming')}</h3><div class="list">${open.length ? open.map(card).join('') : `<div class="empty">${t('none')}</div>`}</div></section><section class="panel"><h3>${t('claims')}</h3><div class="list">${mine.length ? mine.map(card).join('') : `<div class="empty">${t('none')}</div>`}</div></section></div>`;
}
function partnersView() {
  return `<h2>${t('partners')}</h2><div class="list">${S.partners.map(p => `<article class="card"><div class="row"><div><h4>${esc(p.name)}</h4><p>${esc(t(p.type))} · ${esc(p.area)} · ${p.capacity} ${t('meals').toLowerCase()}${p.vegOnly ? ' · 🌱' : ''}</p></div><span>${p.demo ? `<span class="pill a">${t('demo')}</span> ` : ''}<span class="pill ${p.verified ? '' : 'a'}">${p.verified ? '✓ ' + t('verified') : t('unverified')}</span></span></div>${S.me && S.me.role === 'admin' ? `<div class="acts"><button class="small" data-a="verify" data-id="${p.id}">✓ / ✗</button></div>` : ''}</article>`).join('')}</div>`;
}
function alertsView() {
  return `<h2>${t('alerts')}</h2><div class="acts" style="margin:0 0 12px"><button class="small" data-a="read">${t('markRead')}</button></div><div class="list">${S.notes.length ? S.notes.map(n => `<article class="card"><div class="row"><div><h4>${n.icon} ${esc(n.title)}</h4><p>${esc(n.body)}</p></div>${n.read ? '' : '<span class="pill a">•</span>'}</div><p style="margin-top:6px">${new Date(n.at).toLocaleString()}</p></article>`).join('') : `<div class="empty">${t('noAlerts')}</div>`}</div>`;
}
function render(poll) {
  nav(); const v = S.view; let h;
  if (v === 'dash' && S.me) h = S.me.role === 'donor' ? donorDash() : S.me.role === 'partner' ? partnerDash() : partnersView();
  else if (v === 'partners') h = partnersView(); else if (v === 'alerts' && S.me) h = alertsView(); else h = home();
  const keep = document.activeElement && document.activeElement.closest && document.activeElement.closest('#listForm');
  if (!(poll && keep && v === 'dash')) $('#app').innerHTML = h;
}
function authForm() {
  const su = S.mode === 'signup', f = (n, l, ty = 'text', x = '') => `<div class="field"><label>${t(l)}</label><input name="${n}" type="${ty}" ${x} required></div>`;
  $('#authForm').innerHTML = `<div class="tabs"><button type="button" class="ghost" data-a="auth" data-m="login">${t('login')}</button><button type="button" class="ghost" data-a="auth" data-m="signup">${t('signup')}</button></div><div class="list">
  ${su ? `<div class="field"><label>${t('iam')}</label><select name="role"><option value="donor">${t('donor')}</option><option value="partner">${t('partner')}</option></select></div>${f('name', 'name')}${f('org', 'org')}${f('area', 'area')}<div class="field"><label>${t('phone')}</label><input name="phone" type="tel"></div>
  <div class="field"><label>${t('otype')} / ${t('cap')}</label><div class="formgrid"><select name="orgType">${TYPES.map(x => `<option value="${x}">${esc(t(x))}</option>`).join('')}</select><input name="capacity" type="number" min="1" value="50"></div></div><label class="field check"><input name="vegOnly" type="checkbox"> ${t('vonly')}</label><p class="sub">(${t('otype')}, ${t('cap')}: ${t('partner')})</p>` : ''}
  ${f('email', 'email', 'email', 'autocomplete="username"')}${f('password', 'pw', 'password', `minlength="8" autocomplete="${su ? 'new' : 'current'}-password"`)}</div><div class="err" id="authErr" role="alert"></div><button class="primary full-btn" type="submit">${su ? t('signup') : t('login')}</button>`;
}
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a, d = b.dataset;
  try {
    if (a === 'go') { S.view = d.v; load(); }
    else if (a === 'lang') { S.lang = S.lang === 'en' ? 'te' : 'en'; localStorage.setItem('lang', S.lang); if (S.mode) authForm(); render(); }
    else if (a === 'auth') { S.mode = d.m; authForm(); if (!$('#auth').open) $('#auth').showModal(); }
    else if (a === 'logout') { await api('logout', 'POST'); S.me = null; S.view = 'home'; S.listings = []; S.notes = []; render(); }
    else if (a === 'geo') navigator.geolocation ? navigator.geolocation.getCurrentPosition(p => { S.geo = { lat: p.coords.latitude, lng: p.coords.longitude }; b.textContent = t('locOk'); }, () => toast('Location blocked. Matching will use the area name.')) : toast('Location not supported.');
    else if (a === 'auto') { S.auto = b.checked; b.previousElementSibling.textContent = S.auto ? t('autoOn') : t('autoOff'); }
    else if (a === 'alert') { await api(`listings/${d.id}/alert`, 'POST', { partnerId: +d.p }); toast('✓'); load(); }
    else if (['cancel', 'claim'].includes(a)) { await api(`listings/${d.id}/${a}`, 'POST'); toast('✓'); load(); }
    else if (a === 'status') { await api(`listings/${d.id}/status`, 'POST', { status: d.s }); toast('✓'); load(); }
    else if (a === 'verify') { await api(`partners/${d.id}/verify`, 'POST'); load(); }
    else if (a === 'read') { await api('notifications', 'POST'); load(); }
  } catch (err) { toast(err.message); }
});
document.addEventListener('submit', async e => {
  const f = e.target; if (!['listForm', 'authForm'].includes(f.id)) return; e.preventDefault(); const v = Object.fromEntries(new FormData(f)), err = $(f.id === 'listForm' ? '#formErr' : '#authErr');
  try {
    if (f.id === 'authForm') {
      v.vegOnly = !!v.vegOnly; if (S.geo) Object.assign(v, S.geo); const r = await api(S.mode === 'signup' ? 'register' : 'login', 'POST', v); S.me = r.user; S.view = 'dash'; $('#auth').close(); await load();
    } else {
      const d = new Date(); const [h, m] = v.time.split(':'); d.setHours(+h, +m, 0, 0); if (d > Date.now() + 3e5) d.setDate(d.getDate() - 1);
      await api('listings', 'POST', { ...v, veg: !!v.veg, auto: S.auto, preparedAt: d.toISOString(), ...(S.geo || {}) }); toast(t('saved')); await load();
    }
  } catch (x) { err.textContent = x.message; }
});
setInterval(() => { if (S.me && !document.hidden) load(true); }, 20000);
load();
