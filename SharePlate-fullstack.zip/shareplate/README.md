# SharePlate 2.0 — Food Rescue Network (full-stack)

Hostels/schools/colleges list surplus cooked food → the app matches nearby orphanages, old-age homes and trusts → partners claim, collect and confirm delivery. English + Telugu.

## Run (needs only Node.js 18+, no npm install)
    node server.js        # then open http://localhost:3000

Demo logins (password `demo1234`): `hostel@demo.shareplate` (donor), `partner1@demo.shareplate` … `partner4@demo.shareplate` (partners).
Set `SEED_DEMO=0` before real use. Config: see `.env.example`.

## What's real
- Backend REST API (`server.js`), data saved in `data/db.json`, scrypt password hashing, signed HttpOnly sessions, rate limiting, security headers.
- Roles: donor, partner, admin (set `ADMIN_EMAIL`; admins verify partners).
- Food-safety engine: unknown storage is blocked; each listing gets a live countdown (hot 4 h, refrigerated 12 h, room temp 2 h — conservative guideline, confirm with local rules) and auto-expires.
- Smart matching: real distance (browser location) or area text, capacity fit, veg-only homes, verified bonus.
- Auto mode alerts the top 3 partners; manual mode lets the donor alert chosen ones.
- Lifecycle: open → claimed → picked up → delivered, with notifications for both sides.
- Impact dashboard (meals, kg, CO2 — estimates), top-donor leaderboard, CSV report.
- Real SMS: add Twilio keys in env; otherwise alerts are saved to `data/outbox.log`.

## Deploy
Any Node host (Render, Railway, a VPS): start command `node server.js`, keep `data/` on a persistent disk.

## To stand out further
Run a real pilot with 2–3 hostels and several verified homes in Guntur and show the real numbers on the home page; enable Twilio so judges receive an actual SMS; for scale, move `db.json` to PostgreSQL.
