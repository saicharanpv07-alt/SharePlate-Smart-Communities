'use strict';
// SharePlate backend — zero dependencies (Node 18+). Run: node server.js
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const PORT = +process.env.PORT || 3000, DIR = path.join(__dirname, 'data'), DBF = path.join(DIR, 'db.json'), PUB = path.join(__dirname, 'public');
fs.mkdirSync(DIR, { recursive: true });
let SECRET = process.env.SESSION_SECRET; const SK = path.join(DIR, 'secret.key');
if (!SECRET) { try { SECRET = fs.readFileSync(SK, 'utf8'); } catch { SECRET = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(SK, SECRET, { mode: 0o600 }); } }
let db = { users: [], partners: [], listings: [], notes: [], seq: 1 };
try { db = JSON.parse(fs.readFileSync(DBF, 'utf8')); } catch {}
const save = () => { const t = DBF + '.tmp'; fs.writeFileSync(t, JSON.stringify(db)); fs.renameSync(t, DBF); };
const nid = () => db.seq++;

// ---------- security helpers ----------
const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) => salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const check = (pw, h) => { const [s, k] = h.split(':'); return crypto.timingSafeEqual(Buffer.from(k, 'hex'), crypto.scryptSync(pw, s, 32)); };
const mac = b => crypto.createHmac('sha256', SECRET).update(b).digest('base64url');
const sign = d => { const b = Buffer.from(JSON.stringify(d)).toString('base64url'); return b + '.' + mac(b); };
const verify = t => { if (!t) return; const [b, m] = t.split('.'); if (!m || m.length !== mac(b).length || !crypto.timingSafeEqual(Buffer.from(m), Buffer.from(mac(b)))) return; try { const d = JSON.parse(Buffer.from(b, 'base64url')); return d.exp > Date.now() ? d : undefined; } catch {} };
const hits = new Map(); setInterval(() => hits.clear(), 60000).unref();
const limited = (ip, k, max) => { const key = ip + k, n = (hits.get(key) || 0) + 1; hits.set(key, n); return n > max; };

// ---------- domain ----------
const HRS = { 'Hot-held': 4, 'Refrigerated': 12, 'Room temperature': 2 }; // safe hours after preparation (conservative guideline)
const norm = s => (s || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const km = (a, b) => { const r = x => x * Math.PI / 180, dl = r(b.lat - a.lat), dn = r(b.lng - a.lng), h = Math.sin(dl / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(dn / 2) ** 2; return 12742 * Math.asin(Math.sqrt(h)); };
const hasGeo = o => typeof o.lat === 'number' && typeof o.lng === 'number';
function score(l, p) {
  if (p.vegOnly && !l.veg) return null;                       // never match non-veg to veg-only homes
  let s = 0, d = null;
  if (hasGeo(l) && hasGeo(p)) { d = km(l, p); s += Math.max(0, 45 - d * 5); }
  else { const a = norm(l.area), b = norm(p.area); if (a && b && (b.includes(a) || a.includes(b.split(' ')[0]) || b.split(' ').some(w => w.length > 3 && a.includes(w)))) s += 30; }
  s += l.meals <= p.capacity ? 30 : Math.max(0, 30 - (l.meals - p.capacity) / 5);
  if (p.verified) s += 15;
  if (p.type !== 'Community kitchen') s += 5;
  if (l.veg && p.vegOnly) s += 5;
  return { partnerId: p.id, score: Math.round(s), km: d == null ? null : Math.round(d * 10) / 10 };
}
const rank = l => db.partners.map(p => score(l, p)).filter(x => x && x.score > 0).sort((a, b) => b.score - a.score);
const pub = u => ({ id: u.id, name: u.name, email: u.email, role: u.role, org: u.org, area: u.area, phone: u.phone, partnerId: u.partnerId });
const pubPartner = (p, own) => ({ id: p.id, name: p.name, type: p.type, area: p.area, capacity: p.capacity, vegOnly: p.vegOnly, verified: p.verified, demo: !!p.demo, ...(own ? { phone: p.phone } : {}) });
function refresh() { const n = Date.now(); let c = 0; for (const l of db.listings) if ((l.status === 'open' || l.status === 'claimed') && l.expiresAt < n) { l.status = 'expired'; c++; } if (c) save(); }
function notify(uid, title, body, icon = '🔔') {
  const u = db.users.find(x => x.id === uid); if (!u) return;
  db.notes.push({ id: nid(), uid, title, body, icon, at: Date.now(), read: false });
  fs.appendFile(path.join(DIR, 'outbox.log'), `${new Date().toISOString()} to=${u.email}|${u.phone || '-'} ${title}: ${body}\n`, () => {});
  sms(u.phone, `${title}: ${body}`);
}
async function sms(to, msg) {
  const { TWILIO_SID: s, TWILIO_TOKEN: k, TWILIO_FROM: f } = process.env; if (!s || !k || !f || !to) return;
  try { await fetch(`https://api.twilio.com/2010-04-01/Accounts/${s}/Messages.json`, { method: 'POST', headers: { Authorization: 'Basic ' + Buffer.from(s + ':' + k).toString('base64'), 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ To: to, From: f, Body: msg.slice(0, 300) }) }); } catch (e) { console.error('SMS failed:', e.message); }
}
function seed() {
  if (db.users.length || process.env.SEED_DEMO === '0') return;
  const mk = (name, email, role, org, area, extra = {}) => { const u = { id: nid(), name, email, role, org, area, phone: '', pw: hash('demo1234'), ...extra }; db.users.push(u); return u; };
  mk('Demo Hostel Warden', 'hostel@demo.shareplate', 'donor', 'Sunrise College Hostel', 'Brodipet, Guntur');
  [['Ananda Children’s Home', 'Orphanage', 'Brodipet, Guntur', 65, true, 16.3036, 80.4410], ['Seva Old-Age Care', 'Old-age home', 'Arundelpet, Guntur', 40, false, 16.3000, 80.4380], ['Community Meal Trust', 'Community trust', 'Lakshmipuram, Guntur', 120, false, 16.3100, 80.4450], ['Hope Community Kitchen', 'Community kitchen', 'Nallapadu, Guntur', 90, false, 16.3350, 80.4000]]
    .forEach(([name, type, area, capacity, vegOnly, lat, lng], i) => {
      const p = { id: nid(), name, type, area, capacity, vegOnly, lat, lng, verified: false, demo: true, phone: '' };
      const u = mk(name + ' (demo)', `partner${i + 1}@demo.shareplate`, 'partner', name, area, { partnerId: p.id }); p.userId = u.id; db.partners.push(p);
    });
  save(); console.log('Demo accounts: hostel@demo.shareplate / partner1@demo.shareplate … partner4@demo.shareplate  (password: demo1234)');
}
seed();

// ---------- http plumbing ----------
const json = (res, code, obj, h = {}) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...h }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, no) => { let s = ''; req.on('data', c => { s += c; if (s.length > 1e5) { no(new Error('Too large')); req.destroy(); } }); req.on('end', () => { try { ok(s ? JSON.parse(s) : {}); } catch { no(new Error('Bad JSON')); } }); });
const cookie = req => Object.fromEntries((req.headers.cookie || '').split(';').map(c => c.trim().split('=')).filter(x => x[0]));
const str = (v, n = 120) => String(v ?? '').trim().slice(0, n);
const num = v => (typeof v === 'number' && isFinite(v) ? v : undefined);
class HttpErr extends Error { constructor(c, m) { super(m); this.code = c; } }
const bad = m => new HttpErr(400, m);

async function api(req, res, url) {
  const ip = req.socket.remoteAddress, P = url.pathname.slice(5), M = req.method;
  if (limited(ip, 'all', 300)) throw new HttpErr(429, 'Too many requests. Please wait a minute.');
  const sess = verify(cookie(req).sp), me = sess && db.users.find(u => u.id === sess.uid);
  const need = (...roles) => { if (!me) throw new HttpErr(401, 'Please log in.'); if (roles.length && !roles.includes(me.role)) throw new HttpErr(403, 'Not allowed for your account type.'); return me; };
  const setSession = u => ({ 'Set-Cookie': `sp=${sign({ uid: u.id, exp: Date.now() + 7 * 864e5 })}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800` });
  refresh();

  if (P === 'register' && M === 'POST') {
    if (limited(ip, 'auth', 10)) throw new HttpErr(429, 'Too many attempts.');
    const b = await body(req), email = str(b.email).toLowerCase(), role = b.role === 'partner' ? 'partner' : 'donor';
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw bad('Enter a valid email.');
    if (str(b.password, 200).length < 8) throw bad('Password must be at least 8 characters.');
    if (db.users.some(u => u.email === email)) throw bad('This email is already registered.');
    if (!str(b.name) || !str(b.org) || !str(b.area)) throw bad('Name, organization and area are required.');
    const u = { id: nid(), name: str(b.name), email, role: process.env.ADMIN_EMAIL && email === process.env.ADMIN_EMAIL.toLowerCase() ? 'admin' : role, org: str(b.org), area: str(b.area), phone: str(b.phone, 20), pw: hash(str(b.password, 200)) };
    if (role === 'partner') {
      const p = { id: nid(), userId: u.id, name: u.org, type: ['Orphanage', 'Old-age home', 'Community trust', 'Community kitchen'].includes(b.orgType) ? b.orgType : 'Community trust', area: u.area, capacity: Math.min(5000, Math.max(1, Math.round(+b.capacity) || 50)), vegOnly: !!b.vegOnly, lat: num(b.lat), lng: num(b.lng), phone: u.phone, verified: false };
      u.partnerId = p.id; db.partners.push(p);
    }
    db.users.push(u); save(); return json(res, 200, { user: pub(u) }, setSession(u));
  }
  if (P === 'login' && M === 'POST') {
    if (limited(ip, 'auth', 10)) throw new HttpErr(429, 'Too many attempts.');
    const b = await body(req), u = db.users.find(x => x.email === str(b.email).toLowerCase());
    if (!u || !check(str(b.password, 200), u.pw)) throw new HttpErr(401, 'Wrong email or password.');
    return json(res, 200, { user: pub(u) }, setSession(u));
  }
  if (P === 'logout' && M === 'POST') return json(res, 200, { ok: 1 }, { 'Set-Cookie': 'sp=; HttpOnly; Path=/; Max-Age=0' });
  if (P === 'me') return json(res, 200, { user: me ? pub(me) : null });

  if (P === 'stats') {
    const d = db.listings.filter(l => l.status === 'delivered'), meals = d.reduce((s, l) => s + l.meals, 0), by = {};
    d.forEach(l => (by[l.donorName] = (by[l.donorName] || 0) + l.meals));
    return json(res, 200, { meals, kg: Math.round(meals * 0.4), co2: Math.round(meals * 0.4 * 2.5), listed: db.listings.length, partners: db.partners.length, verified: db.partners.filter(p => p.verified).length, top: Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, meals]) => ({ name, meals })) });
  }
  if (P === 'partners' && M === 'GET') return json(res, 200, { partners: db.partners.map(p => pubPartner(p)) });
  let m;
  if ((m = P.match(/^partners\/(\d+)\/verify$/)) && M === 'POST') {
    need('admin'); const p = db.partners.find(x => x.id === +m[1]); if (!p) throw new HttpErr(404, 'Not found'); p.verified = !p.verified; save(); return json(res, 200, { partner: pubPartner(p) });
  }

  if (P === 'listings' && M === 'GET') {
    need('donor', 'partner', 'admin');
    const view = l => ({ ...l, matches: (l.matches || []).map(x => ({ ...x, name: (db.partners.find(p => p.id === x.partnerId) || {}).name })), claimedName: (db.partners.find(p => p.id === l.claimedBy) || {}).name });
    if (me.role === 'partner') {
      const p = db.partners.find(x => x.id === me.partnerId);
      const out = db.listings.filter(l => l.status === 'open' || l.claimedBy === p.id)
        .map(l => { const s = score(l, p); return { ...l, contact: l.claimedBy === p.id ? l.contact : undefined, matches: undefined, score: s ? s.score : 0, km: s ? s.km : null, alerted: (l.alerted || []).includes(p.id) }; })
        .filter(l => l.claimedBy === p.id || l.score > 0).sort((a, b) => b.createdAt - a.createdAt);
      return json(res, 200, { listings: out });
    }
    return json(res, 200, { listings: db.listings.filter(l => me.role === 'admin' || l.donorId === me.id).sort((a, b) => b.createdAt - a.createdAt).map(view) });
  }
  if (P === 'listings' && M === 'POST') {
    need('donor'); const b = await body(req), now = Date.now(), prepared = Date.parse(b.preparedAt);
    if (!HRS[b.storage]) throw bad('Storage is unknown or unsafe. Do not offer this food until a responsible person confirms it was kept safely.');
    const meals = Math.round(+b.meals); if (!(meals >= 1 && meals <= 5000)) throw bad('Enter meals between 1 and 5000.');
    if (!isFinite(prepared) || prepared > now + 3e5 || prepared < now - 864e5) throw bad('Enter a valid preparation time from the last 24 hours.');
    const expiresAt = prepared + HRS[b.storage] * 36e5;
    if (expiresAt - now < 30 * 60000) throw bad(`This food is too close to its safe-time limit (${HRS[b.storage]} h for "${b.storage}"). Please do not donate it.`);
    if (!str(b.area) || !str(b.food)) throw bad('Food type and area are required.');
    const l = { id: nid(), donorId: me.id, donorName: me.org, food: str(b.food), meals, veg: !!b.veg, area: str(b.area), lat: num(b.lat), lng: num(b.lng), storage: b.storage, preparedAt: prepared, expiresAt, notes: str(b.notes, 300), contact: str(b.contact || me.phone, 20), status: 'open', auto: !!b.auto, alerted: [], createdAt: now };
    l.matches = rank(l).slice(0, 5);
    if (l.auto) for (const x of l.matches.slice(0, 3)) alertPartner(l, x.partnerId);
    db.listings.push(l); save(); return json(res, 200, { listing: l });
  }
  if ((m = P.match(/^listings\/(\d+)\/(claim|status|cancel|alert)$/)) && M === 'POST') {
    const l = db.listings.find(x => x.id === +m[1]); if (!l) throw new HttpErr(404, 'Listing not found.'); const b = await body(req);
    if (m[2] === 'alert') { need('donor'); if (l.donorId !== me.id || l.status !== 'open') throw new HttpErr(403, 'Not allowed.'); const p = db.partners.find(x => x.id === +b.partnerId); if (!p) throw bad('Unknown partner.'); alertPartner(l, p.id); }
    if (m[2] === 'cancel') { need('donor'); if (l.donorId !== me.id || !['open', 'claimed'].includes(l.status)) throw new HttpErr(403, 'Not allowed.'); l.status = 'cancelled'; if (l.claimedBy) notify(db.partners.find(p => p.id === l.claimedBy).userId, 'Listing cancelled', `${l.donorName} cancelled ${l.meals} meals.`, '⚠️'); }
    if (m[2] === 'claim') { need('partner'); if (l.status !== 'open') throw bad('Someone already claimed this, or it expired.'); l.status = 'claimed'; l.claimedBy = me.partnerId; l.claimedAt = Date.now(); notify(l.donorId, 'Partner confirmed', `${me.org} will collect ${l.meals} meals. Please keep the food ready.`, '🤝'); }
    if (m[2] === 'status') {
      need('partner'); const next = { claimed: 'picked_up', picked_up: 'delivered' }[l.status];
      if (l.claimedBy !== me.partnerId || b.status !== next) throw bad('Invalid status change.'); l.status = next; if (next === 'delivered') l.deliveredAt = Date.now();
      notify(l.donorId, next === 'delivered' ? 'Meals delivered 🎉' : 'Food picked up', `${me.org}: ${l.meals} meals ${next === 'delivered' ? 'delivered. Thank you for reducing waste!' : 'collected.'}`, next === 'delivered' ? '💚' : '🚚');
    }
    save(); return json(res, 200, { listing: l });
  }
  if (P === 'notifications') { need(); const mine = db.notes.filter(n => n.uid === me.id).sort((a, b) => b.at - a.at).slice(0, 50); if (M === 'POST') { mine.forEach(n => (n.read = true)); save(); } return json(res, 200, { notes: mine }); }
  if (P === 'report.csv') {
    need('donor', 'admin'); const rows = db.listings.filter(l => me.role === 'admin' || l.donorId === me.id), q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const csv = ['id,date,food,meals,status,partner'].concat(rows.map(l => [l.id, new Date(l.createdAt).toISOString(), q(l.food), l.meals, l.status, q((db.partners.find(p => p.id === l.claimedBy) || {}).name)].join(','))).join('\n');
    res.writeHead(200, { 'Content-Type': 'text/csv', 'Content-Disposition': 'attachment; filename="shareplate-report.csv"' }); return res.end(csv);
  }
  throw new HttpErr(404, 'Not found');
}
function alertPartner(l, pid) {
  const p = db.partners.find(x => x.id === pid); if (!p || (l.alerted = l.alerted || []).includes(pid)) return; l.alerted.push(pid);
  if (p.userId) notify(p.userId, 'Food available nearby', `${l.meals} meals (${l.food}${l.veg ? ', veg' : ''}) from ${l.donorName}, ${l.area}. Pickup before ${new Date(l.expiresAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}.`, '🍲');
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json', '.png': 'image/png', '.ico': 'image/x-icon' };
http.createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('X-Frame-Options', 'DENY'); res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'");
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    let f = path.normalize(path.join(PUB, url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname)));
    if (!f.startsWith(PUB) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) f = path.join(PUB, 'index.html');
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' }); fs.createReadStream(f).pipe(res);
  } catch (e) { const code = e.code && Number.isInteger(e.code) ? e.code : 500; if (code === 500) console.error(e); if (!res.headersSent) json(res, code, { error: code === 500 ? 'Server error' : e.message }); }
}).listen(PORT, () => console.log(`SharePlate running at http://localhost:${PORT}`));
